package myinterface;

public interface Book {
	
	int borrow();	// ����
	
	int returnBook();	// �ݳ�

	boolean read();
}
